function NotFoundPage() {
    return (
        <div>
            <h1>Error! Page Not Found</h1>
        </div>
    );
}

export default NotFoundPage;